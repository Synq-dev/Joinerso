# Debug flag to control logging verbosity
debug = False  # Set to True to enable detailed debug logs, False to disable

import requests, json, random, time, msvcrt, ctypes, threading
import concurrent.futures
import sys
import string  # NEW: Added for session_id character set
from pathlib import Path
from dataclasses import dataclass
from typing import Optional, Dict, List, Tuple, Set
from curl_cffi import requests as curl_requests
from curl_cffi import CurlError
from data.solver import Solver
from data.logger import NovaLogger
from colorama import init, Fore, Style
import base64
import uuid

shutdown_event = threading.Event()  # Global event to signal shutdown

# Banner display
banner = f"""
{Fore.CYAN}
                        █████▒██▓ ██▓     ██▓   ▓██   ██▓
                        ▓██   ▒▓██▒▓██▒    ▓██▒    ▒██  ██▒
                        ▒████ ░▒██▒▒██░    ▒██░     ▒██ ██░
                        ░▓█▒  ░░██░▒██░    ▒██░     ░ ▐██▓░
                        ░▒█░   ░██░░██████▒░██████▒ ░ ██▒▓░
                        ▒ ░   ░▓  ░ ▒░▓  ░░ ▒░▓  ░  ██▒▒▒ 
                        ░      ▒ ░░ ░ ▒  ░░ ░ ▒  ░▓██ ░▒░ 
                        ░ ░    ▒ ░  ░ ░     ░ ░   ▒ ▒ ░░  
                                ░      ░  ░    ░  ░░ ░     
                                                ░ ░     

                        {Fore.LIGHTCYAN_EX}https://discord.gg/api{Style.RESET_ALL}
"""

# Expanded lists for randomization with locale-to-timezone mapping
LOCALE_TIMEZONE_MAP = {
    "en-US": ["America/New_York", "America/Los_Angeles", "America/Chicago", "America/Denver"],
    "en-GB": ["Europe/London", "Europe/Dublin"],
    "fr-FR": ["Europe/Paris"],
    "de-DE": ["Europe/Berlin"],
    "es-ES": ["Europe/Madrid"],
    "it-IT": ["Europe/Rome"],
    "pt-BR": ["America/Sao_Paulo"],
    "ja-JP": ["Asia/Tokyo"],
    "zh-CN": ["Asia/Shanghai"],
    "zh-TW": ["Asia/Taipei"],
    "ar-SA": ["Asia/Riyadh"],
    "hi-IN": ["Asia/Kolkata"],
    "tr-TR": ["Europe/Istanbul"],
    "pl-PL": ["Europe/Warsaw"],
    "nl-NL": ["Europe/Amsterdam"],
    "sv-SE": ["Europe/Stockholm"],
    "da-DK": ["Europe/Copenhagen"],
    "fi-FI": ["Europe/Helsinki"],
    "no-NO": ["Europe/Oslo"],
    "en-AU": ["Australia/Sydney", "Australia/Melbourne"],
    "en-CA": ["America/Toronto", "America/Vancouver"],
    "es-MX": ["America/Mexico_City"],
}

LOCALES = list(LOCALE_TIMEZONE_MAP.keys())


# NEW: Function to generate a random 32-character session_id
def generate_random_session_id() -> str:
    """Generate a 32-character random session_id using 0-16 characters."""
    characters = string.digits + 'abcdef'  # 0-9, a-f
    session_id = ''.join(random.choices(characters, k=32))
    if debug:
        NovaLogger.note(f"Generated session_id: {session_id}")
    return session_id


# Function to fetch the latest Discord generation number
def fetch_discord_build_number():
    url = "https://api.sockets.lol/discord/build"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            build_number = data.get("clients", {}).get("Discord", {}).get("decoded", {}).get("client_build_number")
            if build_number is not None:
                NovaLogger.note(f"Fetched Discord build number: {build_number}")
                return int(build_number)
            else:
                NovaLogger.fail("Failed to fetch Discord build number: 'client_build_number' not found in response")
                return 406690
        else:
            NovaLogger.fail(f"Failed to fetch Discord build number. Status code: {response.status_code}")
            return 406690
    except requests.exceptions.RequestException as e:
        NovaLogger.fail(f"An error occurred while fetching Discord build number: {str(e)}")
        return 406690
    except (json.JSONDecodeError, KeyError) as e:
        NovaLogger.fail(f"Failed to parse Discord build number response: {str(e)}")
        return 406690


# Function to get a consistent locale and timezone pair
def get_random_locale_timezone():
    locale = random.choice(LOCALES)
    timezone = random.choice(LOCALE_TIMEZONE_MAP[locale])
    return locale, timezone


# Function to generate X-Super-Properties data
def generate_x_super_data(locale: str, timezone: str, build_number: int) -> Dict:
    return {
        "os": "Windows",
        "browser": "Chrome",
        "device": "",
        "system_locale": locale,
        "has_client_mods": False,
        "browser_user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
        "browser_version": "137.0.0.0",
        "os_version": "10",
        "referrer": "",
        "referring_domain": "",
        "referrer_current": "",
        "referring_domain_current": "",
        "release_channel": "stable",
        "client_build_number": build_number,
        "client_event_source": None,
        "client_launch_id": str(uuid.uuid4()),
        "client_heartbeat_session_id": str(uuid.uuid4()),
        "client_app_state": "focused"
    }


# Function to create header profile
def create_header_profile(build_number: int) -> Dict:
    header_locale, header_timezone = get_random_locale_timezone()
    x_super_data = generate_x_super_data(header_locale, header_timezone, build_number)
    x_super_properties = base64.b64encode(json.dumps(x_super_data, separators=(',', ':')).encode('utf-8')).decode(
        'utf-8')

    return {
        "client_id": "chrome_137",
        "x_super_data": x_super_data,
        "headers": {
            "accept": "*/*",
            "accept-encoding": "gzip, deflate, br, zstd",
            "accept-language": f"{header_locale},en;q=0.6",
            "content-type": "application/json",
            "origin": "https://discord.com",
            "priority": "u=1, i",
            "referer": "https://discord.com/channels/@me",
            "sec-ch-ua": '"Google Chrome";v="137", "Chromium";v="137", "Not/A)Brand";v="24"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "sec-gpc": "1",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
            "x-debug-options": "bugReporterEnabled",
            "x-discord-locale": header_locale,
            "x-discord-timezone": header_timezone,
            "x-super-properties": x_super_properties
        }
    }


# Configuration and stats dataclasses
@dataclass
class JoinerConfig:
    delay: int
    proxyless: bool
    threads: int
    max_joins: int
    captcha: Dict


@dataclass
class JoinerStats:
    total: int = 0
    joined: int = 0
    captcha: int = 0
    captcha_solved: int = 0
    failed: int = 0
    locked: int = 0
    invalid: int = 0
    invalid_invites: int = 0
    current: int = 0


# Token management class
class TokenManager:
    def __init__(self, tokens_file: str):
        self.tokens_file = Path(tokens_file)
        self.tokens = self._load_tokens()
        self.token_joins: Dict[str, int] = {}
        self.processed_tokens: Set[str] = set()

    def _load_tokens(self) -> List[str]:
        tokens = list(set(self.tokens_file.read_text().splitlines()))
        if not tokens:
            raise ValueError("No tokens found in input/tokens.txt. Please add tokens to the file.")
        return tokens

    def remove_token(self, token: str) -> None:
        self.tokens = [t for t in self.tokens if t.strip() != token]
        self.tokens_file.write_text('\n'.join(self.tokens) + '\n')

    def increment_joins(self, token: str) -> int:
        self.token_joins[token] = self.token_joins.get(token, 0) + 1
        self.processed_tokens.add(token.strip())
        return self.token_joins[token]

    def get_unprocessed_tokens(self) -> List[str]:
        return [token for token in self.tokens if token.strip() not in self.processed_tokens]

    def save_unprocessed_tokens(self) -> None:
        unprocessed_tokens = self.get_unprocessed_tokens()
        if not unprocessed_tokens:
            if debug:
                NovaLogger.note("No unprocessed tokens to save")
            return

        file_path = Path("output/unprocessed_tokens.txt")
        existing_tokens = set()
        if file_path.exists():
            with open(file_path, "r") as f:
                existing_tokens = {t.strip() for t in f.read().splitlines()}

        with open(file_path, "a") as f:
            for token in unprocessed_tokens:
                if token.strip() not in existing_tokens:
                    f.write(f"{token}\n")
                    existing_tokens.add(token.strip())
        if debug:
            NovaLogger.note(f"Saved {len(unprocessed_tokens)} unprocessed tokens to output/unprocessed_tokens.txt")


# Main Discord joiner class with curl_cffi
class DiscordJoiner:
    def __init__(self, thread_number: int, config: JoinerConfig, stats: JoinerStats, header_profile: Dict):
        self.thread_number = thread_number
        self.config = config
        self.stats = stats
        self.header_profile = header_profile
        self.session = None
        self.proxy = None
        self._setup_session()
        self._get_initial_cookies()

    def _get_session(self, proxy: Optional[str] = None, retries: int = 3):
        for attempt in range(retries):
            try:
                session = curl_requests.Session(impersonate="chrome")
                if proxy:
                    session.proxies = {"http": proxy, "https": proxy}
                if debug:
                    NovaLogger.note(f"Session created with impersonation: chrome, proxy: {proxy or 'None'}",
                                    thread=self.thread_number)
                return session
            except Exception as e:
                NovaLogger.fail(f"Failed to create session [attempt {attempt + 1}/{retries}]: {str(e)}",
                                thread=self.thread_number)
                if attempt == retries - 1:
                    raise Exception("Failed to create session after all retries")
                time.sleep(1)
        raise Exception("Failed to create session after all retries")

    def _setup_session(self):
        if self.config.proxyless:
            self.proxy = None
            self.session = self._get_session()
            NovaLogger.note("Using Proxy [None]", thread=self.thread_number)
        else:
            proxies = Path('input/proxies.txt').read_text().splitlines()
            if not proxies:
                NovaLogger.fail("No proxies found in input/proxies.txt", thread=self.thread_number)
                raise Exception("No proxies available.")

            proxy_list = proxies.copy()
            random.shuffle(proxy_list)
            self.proxy = None

            for proxy in proxy_list:
                parsed_proxy = self._parse_proxy(proxy)
                if not parsed_proxy:
                    continue

                proxy_parts = parsed_proxy.split('@')
                masked_proxy = f"http://****:****@{proxy_parts[1]}" if len(proxy_parts) > 1 else proxies[0]
                if debug:
                    NovaLogger.note(f"[◈] Testing Proxy [{masked_proxy}]", thread=self.thread_number)

                try:
                    session = self._get_session(parsed_proxy)
                    test_response = session.get("https://discord.com/channels/@me", timeout=10)
                    if test_response.status_code in [200, 401, 403]:
                        self.session = session
                        self.proxy = parsed_proxy
                        break
                    else:
                        NovaLogger.fail(f"Proxy failed with status {test_response.status_code}",
                                        thread=self.thread_number)
                except CurlError as e:
                    if e.code == 16:
                        if debug:
                            NovaLogger.fail(f"[⨯] HTTP/2 error, retrying with new proxy", thread=self.thread_number)
                        continue
                    NovaLogger.fail(f"Proxy failed: {str(e)}", thread=self.thread_number)
                    continue
                except Exception as e:
                    NovaLogger.fail(f"Proxy timed out or failed: {str(e)}", thread=self.thread_number)
                    continue

            if not self.session:
                NovaLogger.fail("All proxies failed or timed out", thread=self.thread_number)
                raise Exception("No working proxies available.")

        self.headers = self.header_profile["headers"].copy()

    def _parse_proxy(self, proxy: str) -> Optional[str]:
        try:
            parts = proxy.split(":")
            if len(parts) == 4:
                domain, port, username, password = parts
                return f"http://{username}:{password}@{domain}:{port}".replace('sessionid',
                                                                               str(random.randint(1327390889,
                                                                                                  1399999999)))
            else:
                NovaLogger.fail(f"Invalid proxy format: {proxy} (expected domain:port:username:password)",
                                thread=self.thread_number)
                return None
        except Exception as e:
            NovaLogger.fail(f"Error parsing proxy {proxy}: {str(e)}", thread=self.thread_number)
            return None

    def _get_initial_cookies(self):
        try:
            response = self.session.get("https://discord.com/channels/@me", timeout=10)
            if response.status_code != 200:
                NovaLogger.fail(f"Failed to get initial cookies - Status: {response.status_code}",
                                thread=self.thread_number)
            else:
                NovaLogger.note("Initial cookies obtained", thread=self.thread_number)
                self.session.cookies.update(response.cookies)
        except CurlError as e:
            if e.code == 16:
                if debug:
                    NovaLogger.fail(f"[⨯] HTTP/2 error, retrying with new proxy", thread=self.thread_number)
                self._setup_session()
                self._get_initial_cookies()
            else:
                NovaLogger.fail(f"Failed to get initial cookies: {str(e)}", thread=self.thread_number)
        except Exception as e:
            NovaLogger.fail(f"Failed to get initial cookies: {str(e)}", thread=self.thread_number)

    def _generate_random_headers(self, build_number: int) -> Tuple[Dict, Dict]:
        locale, timezone = get_random_locale_timezone()
        new_x_super_data = generate_x_super_data(locale, timezone, build_number)
        new_x_super_properties = base64.b64encode(
            json.dumps(new_x_super_data, separators=(',', ':')).encode('utf-8')).decode('utf-8')

        headers = self.headers.copy()
        headers["x-super-properties"] = new_x_super_properties
        headers["user-agent"] = new_x_super_data["browser_user_agent"]
        headers["x-discord-locale"] = locale
        headers["accept-language"] = f"{locale},en;q=0.6"
        headers["x-discord-timezone"] = timezone

        return new_x_super_data, headers

    def x_context_properties_fetcher(self, invite: str, token: str) -> Optional[str]:
        """
        Fetches guild and channel IDs for a given invite and generates x-context-properties header.

        Args:
            invite (str): The Discord invite code (e.g., 'lyrarobotics').
            token (str): The Discord token for authentication.

        Returns:
            Optional[str]: Base64-encoded x-context-properties string, or None if the request fails.
        """
        try:
            token_only = token.split(":")[-1]
            masked_token = f"{token_only.split('.')[0]}.*****"
            x_super_data, headers = self._generate_random_headers(
                self.header_profile["x_super_data"]["client_build_number"])
            headers["authorization"] = token_only

            # Prepare the request URL
            url = f"https://discord.com/api/v9/invites/{invite}?inputValue={invite}&with_counts=true&with_expiration=true&with_permissions=true"

            if debug:
                cookies_str = "; ".join([f"{name}={value}" for name, value in self.session.cookies.items()])
                request_details = {
                    "url": url,
                    "method": "GET",
                    "headers": headers,
                    "cookies": cookies_str if cookies_str else "None",
                    "proxy": self.proxy if self.proxy else "None"
                }
                NovaLogger.note(f"x-context-properties Request Details:\n{json.dumps(request_details, indent=2)}",
                                thread=self.thread_number)

            # Make the request
            response = self.session.get(url, headers=headers, timeout=10)

            if debug:
                NovaLogger.note(f"x-context-properties Response Status: {response.status_code}, Text: {response.text}",
                                thread=self.thread_number)

            if response.status_code != 200:
                NovaLogger.fail(f"Failed to fetch x-context-properties - Status: {response.status_code}",
                                token=masked_token, thread=self.thread_number)
                return None

            try:
                response_json = response.json()
                guild_id = response_json.get("guild_id")
                channel_id = response_json.get("channel", {}).get("id")
                channel_type = response_json.get("channel", {}).get("type", 0)

                if not guild_id or not channel_id:
                    NovaLogger.fail("Missing guild_id or channel_id in response", token=masked_token,
                                    thread=self.thread_number)
                    return None

                # Construct x-context-properties data
                x_context_data = {
                    "location": "Join Guild",
                    "location_guild_id": guild_id,
                    "location_channel_id": channel_id,
                    "location_channel_type": channel_type
                }

                # Encode to base64
                x_context_properties = base64.b64encode(
                    json.dumps(x_context_data, separators=(',', ':')).encode('utf-8')).decode('utf-8')

                if debug:
                    NovaLogger.note(f"Generated x-context-properties: {x_context_properties}",
                                    thread=self.thread_number)

                return x_context_properties

            except json.JSONDecodeError:
                NovaLogger.fail("Failed to parse x-context-properties response", token=masked_token,
                                thread=self.thread_number)
                return None
            except KeyError as e:
                NovaLogger.fail(f"Missing key in response: {str(e)}", token=masked_token, thread=self.thread_number)
                return None

        except CurlError as e:
            if e.code == 16:
                if debug:
                    NovaLogger.fail(f"[⨯] HTTP/2 error, retrying with new proxy", thread=self.thread_number)
                self._setup_session()
                return self.x_context_properties_fetcher(invite, token)
            else:
                NovaLogger.fail(f"Failed to fetch x-context-properties: {str(e)}", token=masked_token,
                                thread=self.thread_number)
                return None
        except Exception as e:
            NovaLogger.fail(f"Error fetching x-context-properties: {str(e)}", token=masked_token,
                            thread=self.thread_number)
            return None

    def _handle_captcha(self, rqdata: str, rqtoken: str, headers: Dict, payload: Dict, invite: str, token: str) -> \
            Tuple[Optional[str], str]:
        retries = self.config.captcha.get("captcha_attempts", 1)
        masked_token = f"{token.split('.')[-1].split('.')[0]}.*****"
        for attempt in range(retries):
            try:
                solver = Solver()
                solver_map = {
                    "razorcap": lambda: solver.razorcap(rqdata=rqdata, proxy=self.proxy),
                    "freecap": lambda: solver.freecap(rqdata=rqdata, proxy=self.proxy)
                }
                if solver_func := solver_map.get(self.config.captcha["service"]):
                    if debug:
                        NovaLogger.note(
                            f"Attempting to solve captcha (attempt {attempt + 1}/{retries}) using {self.config.captcha['service']}",
                            thread=self.thread_number)
                    solution = solver_func()
                    if solution:
                        self.stats.captcha_solved += 1
                        NovaLogger.win("Captcha Solved Successfully", thread=self.thread_number)
                        return solution, "solved"
                    else:
                        if debug:
                            NovaLogger.fail(
                                f"Captcha Solving Failed - No solution returned by {self.config.captcha['service']}",
                                thread=self.thread_number)
                        if attempt < retries - 1:
                            time.sleep(2)
                            continue
                else:
                    NovaLogger.fail(f"Unsupported captcha service: {self.config.captcha['service']}",
                                    thread=self.thread_number)
                    break
            except Exception as e:
                if debug:
                    NovaLogger.fail(f"Captcha Solving Failed - Error: {str(e)}", thread=self.thread_number)
                if "Failed to solve captcha challenge" in str(e):
                    NovaLogger.fail("Failed to solve captcha challenge", token=masked_token, thread=self.thread_number)
                else:
                    NovaLogger.fail("Captcha Solving Failed", token=masked_token, thread=self.thread_number)
                if attempt < retries - 1:
                    time.sleep(2)
                    continue
        if debug:
            NovaLogger.fail("Failed to solve captcha challenge", token=masked_token, thread=self.thread_number)
        else:
            NovaLogger.fail("Failed to solve captcha challenge", token=masked_token, thread=self.thread_number)
        return None, "failed"

    def _append_to_file(self, filename: str, content: str):
        file_path = Path(f"output/{filename}")
        if file_path.exists():
            with open(file_path, "r") as f:
                existing_content = f.read().splitlines()
            if content in existing_content:
                return
        with open(file_path, "a") as f:
            f.write(f"{content}\n")

    def _remove_invite_from_file(self, invite: str):
        try:
            invites_file = Path('input/invites.txt')
            invites = invites_file.read_text().splitlines()
            invites = [i.strip() for i in invites if i.strip() != invite]
            invites_file.write_text('\n'.join(invites) + '\n')
            if debug:
                NovaLogger.note(f"Removed invalid invite [{invite}] from input/invites.txt", thread=self.thread_number)
        except Exception as e:
            NovaLogger.fail(f"Failed to remove invite [{invite}] from file: {str(e)}", thread=self.thread_number)

    def _handle_response(self, response, token: str, masked_token: str, invite: str) -> None:
        self.stats.current += 1
        if debug:
            NovaLogger.note(f"Response Status: {response.status_code}, Text: {response.text}",
                            thread=self.thread_number)

        if response.status_code == 429:
            NovaLogger.fail("Rate Limited", token=masked_token, thread=self.thread_number)
            return

        if response.status_code == 200:
            NovaLogger.win("Successfully Joined Server", token=masked_token, thread=self.thread_number)
            self._append_to_file("joined.txt", token)
            self.stats.joined += 1
            return

        if response.status_code == 401:
            NovaLogger.fail("Invalid Token", token=masked_token, thread=self.thread_number)
            self._append_to_file("invalid.txt", token)
            token_manager.remove_token(token)
            self.stats.invalid += 1
            return

        if response.status_code == 403:
            try:
                response_json = response.json()
                if response_json.get("code") == 10008:
                    NovaLogger.fail("Unknown Message error", token=masked_token, thread=self.thread_number)
                    self._append_to_file("failed_token.txt", token)
                    self.stats.failed += 1
                    return
            except json.JSONDecodeError:
                pass

            NovaLogger.fail("Locked Token", token=masked_token, thread=self.thread_number)
            self._append_to_file("locked.txt", token)
            token_manager.remove_token(token)
            self.stats.locked += 1
            return

        if response.status_code == 404:
            try:
                response_json = response.json()
                if response_json.get("code") == 10006:
                    NovaLogger.fail(f"Invalid Invite [{invite}]", token=masked_token, thread=self.thread_number)
                    self.stats.invalid_invites += 1
                    self._remove_invite_from_file(invite)
                    return
            except json.JSONDecodeError:
                pass

        if "captcha_key" in response.text:
            NovaLogger.fail("Failed Due To Solver Issue", token=masked_token,
                            error=response.json().get('captcha_key', 'Unknown captcha error'),
                            thread=self.thread_number)
            self._append_to_file("failed_captcha.txt", token)
            self.stats.failed += 1
            return

        NovaLogger.fail(f"Failed To Join Server", token=masked_token, error=response.text, thread=self.thread_number)
        self._append_to_file("failed.txt", token)
        self.stats.failed += 1

    def join_server(self, token: str, invite: str, build_number: int) -> None:
        if shutdown_event.is_set():
            if debug:
                NovaLogger.note(f"Shutdown event detected, skipping join for token in thread {self.thread_number}")
            return
        try:
            token_only = token.split(":")[-1]
            masked_token = f"{token_only.split('.')[0]}.*****"
            x_super_data, headers = self._generate_random_headers(build_number)
            headers["authorization"] = token_only

            if shutdown_event.is_set():
                if debug:
                    NovaLogger.note(
                        f"Shutdown event detected, skipping x-context-properties fetch in thread {self.thread_number}")
                return
            x_context_properties = self.x_context_properties_fetcher(invite, token)
            if x_context_properties:
                headers["x-context-properties"] = x_context_properties
                if debug:
                    NovaLogger.note(f"Added x-context-properties to headers: {x_context_properties}",
                                    thread=self.thread_number)

            payload = {"session_id": generate_random_session_id()}

            if debug:
                cookies_str = "; ".join([f"{name}={value}" for name, value in self.session.cookies.items()])
                request_details = {
                    "url": f"https://discord.com/api/v9/invites/{invite}",
                    "method": "POST",
                    "headers": headers,
                    "cookies": cookies_str if cookies_str else "None",
                    "body": json.dumps(payload, indent=2),
                    "proxy": self.proxy if self.proxy else "None"
                }
                NovaLogger.note(f"Full Request Details:\n{json.dumps(request_details, indent=2)}",
                                thread=self.thread_number)

            if shutdown_event.is_set():
                if debug:
                    NovaLogger.note(
                        f"Shutdown event detected, skipping initial join request in thread {self.thread_number}")
                return
            try:
                response = self.session.post(
                    f"https://discord.com/api/v9/invites/{invite}",
                    headers=headers,
                    json=payload,
                    timeout=10
                )
            except CurlError as e:
                if e.code == 16:
                    if debug:
                        NovaLogger.fail(f"[⨯] HTTP/2 error, retrying with new proxy", thread=self.thread_number)
                    self._setup_session()
                    if shutdown_event.is_set():
                        if debug:
                            NovaLogger.note(
                                f"Shutdown event detected, skipping retry join request in thread {self.thread_number}")
                        return
                    response = self.session.post(
                        f"https://discord.com/api/v9/invites/{invite}",
                        headers=headers,
                        json=payload,
                        timeout=10
                    )
                else:
                    raise

            if debug:
                NovaLogger.note(f"Initial Request Headers: {headers}", thread=self.thread_number)

            if "captcha_sitekey" in response.text and self.config.captcha["solve_captcha"]:
                NovaLogger.alert("Captcha Detected", token=masked_token, thread=self.thread_number)
                self.stats.captcha += 1

                response_json = response.json()
                captcha_rqdata = response_json.get('captcha_rqdata')
                captcha_rqtoken = response_json.get('captcha_rqtoken')
                captcha_session_id = response_json.get('captcha_session_id')  # Extract captcha_session_id

                solution, captcha_status = self._handle_captcha(
                    captcha_rqdata,
                    captcha_rqtoken,
                    headers=headers,
                    payload=payload,
                    invite=invite,
                    token=token_only
                )

                if solution:
                    headers.update({
                        "x-captcha-key": solution,
                        "x-captcha-rqtoken": captcha_rqtoken,
                        "x-captcha-session-id": captcha_session_id  # Add captcha_session_id to headers
                    })
                    if shutdown_event.is_set():
                        if debug:
                            NovaLogger.note(
                                f"Shutdown event detected, skipping captcha retry request in thread {self.thread_number}")
                        return
                    if debug:
                        cookies_str = "; ".join([f"{name}={value}" for name, value in self.session.cookies.items()])
                        retry_request_details = {
                            "url": f"https://discord.com/api/v9/invites/{invite}",
                            "method": "POST",
                            "headers": headers,
                            "cookies": cookies_str if cookies_str else "None",
                            "body": json.dumps(payload, indent=2),
                            "proxy": self.proxy if self.proxy else "None"
                        }
                        NovaLogger.note(f"Full Request Details:\n{json.dumps(retry_request_details, indent=2)}",
                                        thread=self.thread_number)
                    try:
                        if debug and self.proxy:
                            proxy_parts = self.proxy.split('@')
                            masked_proxy = f"http://****:****@{proxy_parts[1]}" if len(proxy_parts) > 1 else "None"
                            NovaLogger.note(f"[◈] Testing Proxy [{masked_proxy}]", thread=self.thread_number)
                        response = self.session.post(
                            f"https://discord.com/api/v9/invites/{invite}",
                            headers=headers,
                            json=payload,
                            timeout=10
                        )
                    except CurlError as e:
                        if e.code == 16:
                            if debug:
                                NovaLogger.fail(f"[⨯] HTTP/2 error, retrying with new proxy", thread=self.thread_number)
                            self._setup_session()
                            if shutdown_event.is_set():
                                if debug:
                                    NovaLogger.note(
                                        f"Shutdown event detected, skipping second retry request in thread {self.thread_number}")
                                return
                            response = self.session.post(
                                f"https://discord.com/api/v9/invites/{invite}",
                                headers=headers,
                                json=payload,
                                timeout=10
                            )
                        else:
                            raise
                    if debug:
                        NovaLogger.note(f"Retry Request Headers: {headers}", thread=self.thread_number)
                    time.sleep(5)
                else:
                    self._append_to_file("failed_captcha.txt", token)
                    self.stats.failed += 1
                    return

            self._handle_response(response, token, masked_token, invite)

            time.sleep(random.uniform(2, 5))

        except Exception as e:
            if not shutdown_event.is_set():
                NovaLogger.fail(f"Error: {str(e)}", thread=self.thread_number)
                self.stats.failed += 1

# Console title update function (required by main)
def update_title(stats: JoinerStats, done: threading.Event, total_invites: int):
    while not done.is_set():
        try:
            ctypes.windll.kernel32.SetConsoleTitleW(
                f"Filly | "
                f"Total: {total_invites} | "
                f"Joined: {stats.joined} | "
                f"Failed: {stats.failed} | "
                f"Captcha: {stats.captcha} ({stats.captcha_solved} solved) | "
                f"Invalid: {stats.invalid} | "
                f"Locked: {stats.locked} | "
                f"Invalid Invites: {stats.invalid_invites}"
            )
            time.sleep(0.1)
        except Exception as e:
            NovaLogger.fail(f"Title Update Error: {str(e)}")
            break


# Main execution function
def main():
    init()
    done = threading.Event()
    executor = None
    try:
        # Clear all files in the output directory by deleting them
        output_dir = Path('output')
        if output_dir.exists():
            for file_path in output_dir.glob('*.txt'):
                file_path.unlink()
                if debug:
                    print(f"[DEBUG] Deleted output file: {file_path}")
            if debug:
                print("[DEBUG] Cleared all files in output directory")
        else:
            output_dir.mkdir(parents=True, exist_ok=True)
            if debug:
                print("[DEBUG] Created output directory")

        if debug:
            print("[DEBUG] Loading config from input/config.json")
        config_data = json.loads(Path('input/config.json').read_text())
        if debug:
            print(f"[DEBUG] Config loaded: {config_data}")
        config = JoinerConfig(**config_data)

        stats = JoinerStats()

        if debug:
            print("[DEBUG] Loading invites from input/invites.txt")
        invites = list(set(Path('input/invites.txt').read_text().splitlines()))
        if not invites:
            raise ValueError("No invites found in input/invites.txt. Please add invites to the file.")
        if debug:
            print(f"[DEBUG] Loaded {len(invites)} invites")

        if debug:
            print("[DEBUG] Initializing token manager")
        global token_manager
        token_manager = TokenManager("input/tokens.txt")
        if debug:
            print(f"[DEBUG] Loaded {len(token_manager.tokens)} tokens")

        max_joins = min(config.max_joins, len(invites))
        max_threads = min(len(token_manager.tokens), config.threads)
        if debug:
            print(f"[DEBUG] max_joins: {max_joins}, max_threads: {max_threads}")

        if max_joins == 0 or max_threads == 0:
            raise ValueError(
                "Cannot proceed: max_joins or max_threads is 0. Check your tokens, invites, and config settings.")

        print(banner)

        discord_build_number = fetch_discord_build_number()
        header_profile = create_header_profile(discord_build_number)

        if debug:
            print("[DEBUG] Starting title update thread")
        title_thread = threading.Thread(
            target=update_title,
            args=(stats, done, len(invites))
        )
        title_thread.daemon = True
        title_thread.start()

        start_time = time.time()

        if debug:
            print("[DEBUG] Starting token joining loop")
        if max_threads == 1:
            for token_idx, token in enumerate(token_manager.tokens):
                joins = token_manager.increment_joins(token)
                if joins >= config.max_joins:
                    if debug:
                        print(f"[DEBUG] Token {token_idx} has reached max joins ({config.max_joins}), skipping")
                    continue

                thread_number = 1
                if debug:
                    print(f"[DEBUG] Processing token {token_idx} on thread {thread_number}")
                joiner = DiscordJoiner(thread_number, config, stats, header_profile)
                for invite in invites[:max_joins]:
                    joiner.join_server(token.strip(), invite, discord_build_number)
                    if shutdown_event.is_set():
                        break
                if config.delay > 0:
                    NovaLogger.note(f"Sleeping for {config.delay} seconds", thread=thread_number)
                    time.sleep(config.delay)
        else:
            executor = concurrent.futures.ThreadPoolExecutor(max_workers=max_threads)
            futures = []
            token_iterator = iter(enumerate(token_manager.tokens))
            active_threads = 0

            def submit_token(token_idx, token, thread_number):
                if debug:
                    print(f"[DEBUG] Processing token {token_idx} on thread {thread_number}")
                joiner = DiscordJoiner(thread_number, config, stats, header_profile)
                futures.append(executor.submit(
                    lambda: [joiner.join_server(token.strip(), random.choice(invites), discord_build_number)
                             for _ in range(max_joins) if not shutdown_event.is_set()]
                ))

            # Initial thread launch with delay if specified
            while active_threads < max_threads:
                try:
                    token_idx, token = next(token_iterator)
                    joins = token_manager.increment_joins(token)
                    if joins > config.max_joins:
                        if debug:
                            print(f"[DEBUG] Token {token_idx} has reached max joins ({config.max_joins}), skipping")
                        continue

                    thread_number = (active_threads % max_threads) + 1
                    submit_token(token_idx, token, thread_number)
                    active_threads += 1
                    if debug:
                        print(f"[DEBUG] Launched thread {thread_number}, active threads: {active_threads}")

                    if config.delay > 0 and active_threads < max_threads:
                        if debug:
                            NovaLogger.note(f"Sleeping for {config.delay} seconds before next thread", thread=thread_number)
                        time.sleep(config.delay)
                except StopIteration:
                    if debug:
                        print("[DEBUG] No more tokens to launch initially")
                    break

            # Monitor and replace finished threads
            while futures and not shutdown_event.is_set():
                completed, futures = concurrent.futures.wait(futures, timeout=1.0, return_when=concurrent.futures.FIRST_COMPLETED)
                for future in completed:
                    active_threads -= 1
                    if debug:
                        print(f"[DEBUG] Thread completed, active threads: {active_threads}")

                    try:
                        token_idx, token = next(token_iterator)
                        joins = token_manager.increment_joins(token)
                        if joins > config.max_joins:
                            if debug:
                                print(f"[DEBUG] Token {token_idx} has reached max joins ({config.max_joins}), skipping")
                            continue

                        thread_number = (active_threads % max_threads) + 1
                        submit_token(token_idx, token, thread_number)
                        active_threads += 1
                        if debug:
                            print(f"[DEBUG] Launched new thread {thread_number}, active threads: {active_threads}")
                    except StopIteration:
                        if debug:
                            print("[DEBUG] No more tokens to process")
                        break

    except KeyboardInterrupt:
        if debug:
            print("[DEBUG] Caught KeyboardInterrupt, setting shutdown event")
        shutdown_event.set()
        print(f"\n{Fore.YELLOW}Script interrupted by user (Ctrl+C). Saving unprocessed tokens...{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.RED}Critical Error: {str(e)}{Style.RESET_ALL}")
        import traceback
        traceback.print_exc()
    finally:
        if debug:
            print("[DEBUG] Entering finally block")
        done.set()
        title_thread.join(timeout=1.0)

        if executor:
            if debug:
                print("[DEBUG] Shutting down ThreadPoolExecutor")
            executor._threads.clear()  # Force-clear threads
            executor.shutdown(wait=False)
            for future in futures:
                future.cancel()

        if token_manager:
            if debug:
                print("[DEBUG] Saving unprocessed tokens")
            token_manager.save_unprocessed_tokens()

        elapsed = time.time() - start_time
        minutes, seconds = divmod(int(elapsed), 60)

        sep_line = "=" * 50
        print(f"\n{sep_line}")
        print(f"{Fore.CYAN}Final Statistics:{Style.RESET_ALL}")
        print(f"Joined {stats.current} Tokens in {minutes} minutes and {seconds} seconds")
        print("\nSummary:")
        print(f"- Total Processed: {Fore.CYAN}{stats.current}{Style.RESET_ALL}")
        print(f"- Successfully Joined: {Fore.GREEN}{stats.joined}{Style.RESET_ALL}")
        print(
            f"- Captcha Encountered: {Fore.YELLOW}{stats.captcha} {Fore.CYAN}({stats.captcha_solved} solved){Style.RESET_ALL}")
        print(f"- Failed: {Fore.RED}{stats.failed}{Style.RESET_ALL}")
        print(f"- Invalid: {Fore.RED}{stats.invalid}{Style.RESET_ALL}")
        print(f"- Locked: {Fore.RED}{stats.locked}{Style.RESET_ALL}")
        print(f"- Invalid Invites: {Fore.RED}{stats.invalid_invites}{Style.RESET_ALL}")
        print(f"\n{sep_line}")

        print(f"{Fore.YELLOW}Press Enter to exit...{Style.RESET_ALL}")
        while True:
            if msvcrt.kbhit():
                if msvcrt.getch() == b'\r':
                    break
            time.sleep(0.1)

        print(f"{Fore.CYAN}Process finished with exit code 0{Style.RESET_ALL}")
        time.sleep(1)

        try:
            if debug:
                print("[DEBUG] Closing NovaLogger")
            NovaLogger.close()
        except:
            pass
        sys.exit(0)

if __name__ == "__main__":
    token_manager = None
    main()