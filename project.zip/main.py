"""
Discord OAuth2 Rejoin Service — Python + Flask
Advanced version with:
• Text-file storage for users (editable format).
• Automatic refresh token system.
• Webhook logging (embeds).
• Dynamic guild_id support for migration.
• Runs on port 8910.

.env must include:
CLIENT_ID, CLIENT_SECRET, BOT_TOKEN, REDIRECT_URI, ADMIN_KEY, WEBHOOK_URL
"""

import os, time, json, base64
from urllib.parse import urlencode
from dataclasses import dataclass

import requests
from flask import Flask, redirect, request, jsonify
from dotenv import load_dotenv

load_dotenv()
CLIENT_ID = os.getenv("CLIENT_ID")
CLIENT_SECRET = os.getenv("CLIENT_SECRET")
BOT_TOKEN = os.getenv("BOT_TOKEN")
REDIRECT_URI = os.getenv("REDIRECT_URI", "https://auth.betbyte.top/callback")
ADMIN_KEY = os.getenv("ADMIN_KEY", "changeme")
WEBHOOK_URL = os.getenv("WEBHOOK_URL")

DISCORD_API = "https://discord.com/api/v10"
OAUTH_AUTHORIZE = "https://discord.com/api/oauth2/authorize"
OAUTH_TOKEN = f"{DISCORD_API}/oauth2/token"

FILE_PATH = "users.txt"

@dataclass
class UserToken:
    user_id: str
    username: str
    access_token: str
    refresh_token: str
    expires_at: int
    scope: str

    @property
    def expired(self) -> bool:
        return time.time() > (self.expires_at - 60)

# ---------------- File Helpers ----------------

def save_user(u: UserToken):
    users = load_all_users()
    users[u.user_id] = u
    with open(FILE_PATH, "w", encoding="utf8") as f:
        for uid, ut in users.items():
            f.write("--------\n")
            f.write(f"USER: {ut.user_id}\n")
            f.write(f"USERNAME: {ut.username}\n")
            f.write(f"ACCESS: {ut.access_token}\n")
            f.write(f"REFRESH: {ut.refresh_token}\n")
            f.write(f"EXPIRES: {ut.expires_at}\n")
            f.write(f"SCOPES: {ut.scope}\n")

def load_all_users() -> dict[str, UserToken]:
    if not os.path.exists(FILE_PATH):
        return {}
    users: dict[str, UserToken] = {}
    block = {}
    with open(FILE_PATH, "r", encoding="utf8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if line.startswith("--------"):
                if block.get("USER"):
                    users[block["USER"]] = UserToken(
                        user_id=block["USER"],
                        username=block.get("USERNAME", ""),
                        access_token=block.get("ACCESS", ""),
                        refresh_token=block.get("REFRESH", ""),
                        expires_at=int(block.get("EXPIRES", "0")),
                        scope=block.get("SCOPES", "")
                    )
                block = {}
                continue
            if ":" in line:
                k, v = line.split(":", 1)
                block[k.strip()] = v.strip()
    return users

# ---------------- Token Helpers ----------------

def token_request(data: dict) -> dict:
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    r = requests.post(OAUTH_TOKEN, data=data, headers=headers, timeout=15)
    r.raise_for_status()
    return r.json()

def exchange_code(code: str) -> dict:
    return token_request({
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": REDIRECT_URI,
    })

def refresh_token(u: UserToken) -> UserToken:
    data = {
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "grant_type": "refresh_token",
        "refresh_token": u.refresh_token,
    }
    tok = token_request(data)
    u.access_token = tok["access_token"]
    u.refresh_token = tok.get("refresh_token", u.refresh_token)
    u.expires_at = int(time.time()) + int(tok.get("expires_in", 3600))
    save_user(u)
    return u

# ---------------- Discord API ----------------

def get_me(access_token: str) -> dict:
    r = requests.get(f"{DISCORD_API}/users/@me",
                     headers={"Authorization": f"Bearer {access_token}"},
                     timeout=15)
    r.raise_for_status()
    return r.json()

def add_user_to_guild(user_id: str, access_token: str, guild_id: str):
    url = f"{DISCORD_API}/guilds/{guild_id}/members/{user_id}"
    headers = {"Authorization": f"Bot {BOT_TOKEN}", "Content-Type": "application/json"}
    body = {"access_token": access_token}
    r = requests.put(url, headers=headers, data=json.dumps(body), timeout=20)
    return r.status_code, r.json() if r.text else None

# ---------------- Logging ----------------

def log_event(title: str, description: str, color: int = 0x00ffcc):
    if not WEBHOOK_URL:
        return
    embed = {
        "title": title,
        "description": description,
        "color": color,
        "footer": {"text": time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())}
    }
    try:
        requests.post(WEBHOOK_URL, json={"embeds": [embed]}, timeout=10)
    except Exception:
        pass

# ---------------- Flask App ----------------

app = Flask(__name__)
app.secret_key = base64.urlsafe_b64encode(os.urandom(32))

@app.route("/")
def index():
    q = {
        "client_id": CLIENT_ID,
        "redirect_uri": REDIRECT_URI,
        "response_type": "code",
        "scope": "identify guilds.join"
    }
    url = f"{OAUTH_AUTHORIZE}?{urlencode(q)}"
    return f"<h2>Join Recovery System</h2><a href='{url}'><button>Authorize</button></a>"

@app.route("/callback")
def callback():
    code = request.args.get("code")
    if not code:
        return "Missing code", 400
    tok = exchange_code(code)
    access, refresh = tok["access_token"], tok["refresh_token"]
    exp = int(time.time()) + int(tok.get("expires_in", 3600))
    me = get_me(access)
    u = UserToken(
        user_id=str(me["id"]),
        username=f"{me.get('username')}#{me.get('discriminator', '0')}",
        access_token=access,
        refresh_token=refresh,
        expires_at=exp,
        scope=tok.get("scope", "")
    )
    save_user(u)
    log_event("✅ User Authorized", f"**{u.username}** ({u.user_id}) authorized the app.")
    return "<h3>Thanks! You can now be re-added to our new server if migration happens.</h3>"

@app.route("/admin/migrate")
def migrate():
    if request.args.get("key") != ADMIN_KEY:
        return "forbidden", 403

    guild_id = request.args.get("guild_id")
    if not guild_id:
        return "missing guild_id", 400

    users = load_all_users()
    results = {"joined":0, "already":0, "failed":0, "details":[]} 
    for uid, u in users.items():
        if u.expired:
            u = refresh_token(u)
        status, payload = add_user_to_guild(u.user_id, u.access_token, guild_id)
        if status in (200,201):
            results["joined"] += 1
            log_event("👥 User Added", f"**{u.username}** ({u.user_id}) joined guild {guild_id}.")
        elif status == 204:
            results["already"] += 1
        else:
            results["failed"] += 1
            log_event("⚠️ Add Failed", f"**{u.username}** ({u.user_id}) failed to join {guild_id}. Status: {status}")
        results["details"].append({"user":u.username,"status":status,"payload":payload})
        time.sleep(0.25)
    return jsonify(results)

@app.route("/admin/list")
def list_users():
    if request.args.get("key") != ADMIN_KEY:
        return "forbidden", 403
    users = load_all_users()
    return jsonify([u.__dict__ for u in users.values()])

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8910, debug=True)
